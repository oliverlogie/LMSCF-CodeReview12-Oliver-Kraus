<?php if( have_posts() ): while( have_posts() ): the_post();?>

<div clas="card mb-3 ml-5 display-flex" style="width: 20rem;">

    <div class="card-body">
        <img class="card-img-top" src="<?php the_post_thumbnail('medium');?>">
        <h3><?php the_title(); ?></h3>
        <?php the_excerpt(); ?>

        <a href="<?php the_permalink(); ?>" class="btn btn-success"> Read more</a>
    </div>
</div>
<?php endwhile; else: endif;?>