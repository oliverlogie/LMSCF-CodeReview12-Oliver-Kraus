<?php get_header(); ?>
<section >
<img class="background" style="height:700px; width: 100%;" src="<?php the_post_thumbnail('full'); ?>">
<div class="row">
        <div class="col-lg-6 offset-2">
        <h1 class="display-3"><?php the_title(); ?></h1>
        <?php get_template_part('includes/section', 'content');?>
        </div>
        <div class="col-lg-3">
        <?php
                if(is_active_sidebar('sidebar')):
                dynamic_sidebar('sidebar');
                endif;  
        ?>
</div>
</div>
</section>
<?php get_footer(); ?>