<?php get_header(); ?>

<div class="container pt-4">
<div class="row display-flex justify-content-between">
        
        <?php get_template_part('includes/section', 'archive');?>
</div>
</div>

<?php get_footer(); ?>