
<footer>
    <div class="container">
</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>