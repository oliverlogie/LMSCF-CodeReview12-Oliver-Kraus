<?php

/*
Template Name: Contact Us
*/

?>

<?php get_header(); ?>

<div class="container pt-4">

        <h1  class="display-3"><?php the_title(); ?></h1>
        <?php get_template_part('includes/section', 'content');?>

</div>

<?php get_footer(); ?>